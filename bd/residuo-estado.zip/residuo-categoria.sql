INSERT INTO categoria_residuos (categoria_residuo_id, descripcion_categoria_residuo)
VALUES (1, 'Interior'),
(2, 'Exterior'),
(3, 'Construcción'),
(4, 'Puertas'),
(5, 'Ventanas');