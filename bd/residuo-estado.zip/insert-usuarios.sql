INSERT INTO usuarios(usuario_id, contrasenha, direccion_empresa, email, fecha_creacion, nombre_empresa, telefono_empresa, usuario_apellido, usuario_nombre, rol_usuario_id) 
VALUES(1, "", "Av. Empresa1", "empresa1@empresa.cl", '2024-03-06 10:30:00', "Emresa1", "+1234567890", "LastName1", "FirstName1", 1),
(2, "", "Av. Empresa2", "empresa2@empresa.cl", '2024-03-06 10:30:00', "Emresa2", "+1234567890", "LastName2", "FirstName2", 2),
(3, "", "Av. Empresa3", "empresa3@empresa.cl", '2024-03-06 10:30:00', "Emresa3", "+1234567890", "LastName3", "FirstName3", 3);
(4, "", , "empresa3@empresa.cl", '2024-03-06 10:30:00', , "+1234567890", "LastName3", "FirstName3", 3);